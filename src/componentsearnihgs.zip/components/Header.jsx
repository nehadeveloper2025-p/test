export default function Header(){
return (
<header className="sticky top-0 ">
<div className="mx-auto max-w-6xl flex items-center justify-between px-4 py-2">
<div className="flex items-center gap-2">
     <img src="/epaysliplogo.png" 
              alt="ePay Slip Logo"
                 style={{ height: "40px", width: "auto" }}
            />
</div>
<nav className="hidden md:flex items-center gap-6 text-md text-slate-600">
<a href="#" className="hover:text-slate-900 font-semibold">Home</a>
<a href="#" className="hover:text-slate-900 font-semibold">Features</a>
<a href="#" className="hover:text-slate-900 font-semibold">Pricing</a>
</nav>
<div className="flex items-center gap-2">
<button className="px-3 py-1.5 text-sm rounded-xl border">Sign Up</button>
<button className="px-3 py-1.5 text-sm rounded-xl bg-slate-900 text-white">Login</button>
</div>
</div>
</header>
)
}