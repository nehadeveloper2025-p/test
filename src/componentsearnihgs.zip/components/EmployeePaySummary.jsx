// components/EmployeePaySummary.jsx
import React from "react";
import Input from "../components/ui/Input";

// Adaptive label width keeps colons aligned but fits the card on smaller screens
const LABEL_W = "clamp(90px, 16vw, 130px)";

const makeId = () =>
  Math.random().toString(36).slice(2) + Date.now().toString(36);

const get = (obj, path) =>
  path.split(".").reduce((o, k) => (o ? o[k] : undefined), obj);

export default function EmployeePaySummary({
  employee,
  setEmployee,
  errors = {},
  submitted,
}) {
  const addField = () =>
    setEmployee((prev) => ({
      ...prev,
      extraFields: [
        ...(prev.extraFields || []),
        { id: makeId(), label: "", value: "" },
      ],
    }));

  const updateField = (id, patch) =>
    setEmployee((prev) => ({
      ...prev,
      extraFields: (prev.extraFields || []).map((f) =>
        f.id === id ? { ...f, ...patch } : f
      ),
    }));

  const deleteField = (id) =>
    setEmployee((prev) => ({
      ...prev,
      extraFields: (prev.extraFields || []).filter((f) => f.id !== id),
    }));

  return (
    <section className="rounded-[8px] border p-4 md:p-5  border-[#10324F]/40 shadow-sm overflow-x-hidden">
      {/* Fixed fields (2 columns) */}
      <div className="grid grid-cols-2 gap-3">
        <Input
          variant="row"
          labelWidth={LABEL_W}
          label="Employee Name"
          data-error-key="employee.name"
          placeholder="Name"
          value={employee.name || ""}
          onChange={(v) => setEmployee((e) => ({ ...e, name: v }))}
          error={submitted ? get(errors, "employee.name") || "" : ""}
        />
        <Input
          variant="row"
          labelWidth={LABEL_W}
          label="Employee ID"
          data-error-key="employee.employeeId"
          placeholder="Employee Id"
          value={employee.employeeId || ""}
          onChange={(v) => setEmployee((e) => ({ ...e, employeeId: v }))}
          error={submitted ? get(errors, "employee.employeeId") || "" : ""}
        />
        <Input
          variant="row"
          labelWidth={LABEL_W}
          label="Employee Email"
          data-error-key="employee.email"
          placeholder="email"
          value={employee.email || ""}
          onChange={(v) => setEmployee((e) => ({ ...e, email: v }))}
          error={submitted ? get(errors, "employee.email") || "" : ""}
        />
        <Input
          variant="row"
          labelWidth={LABEL_W}
          label="Mobile No"
          data-error-key="employee.phoneno"
          placeholder="Mobile No."
          value={employee.phoneno || ""}
          onChange={(v) => setEmployee((e) => ({ ...e, phoneno: v }))}
          error={submitted ? get(errors, "employee.phoneno") || "" : ""}
        />
        <Input
          variant="row"
          labelWidth={LABEL_W}
          label="Designation"
          data-error-key="employee.designation"
          placeholder="Designation"
          value={employee.designation || ""}
          onChange={(v) => setEmployee((e) => ({ ...e, designation: v }))}
          error={submitted ? get(errors, "employee.designation") || "" : ""}
        />
        <Input
          variant="row"
          labelWidth={LABEL_W}
          label="Paid Days"
          data-error-key="employee.paidDays"
          placeholder="Paid Days"
          value={String(employee.paidDays || "")}
          onChange={(v) => setEmployee((e) => ({ ...e, paidDays: v }))}
          error={submitted ? get(errors, "employee.paidDays") || "" : ""}
        />
        <Input
          variant="row"
          labelWidth={LABEL_W}
          label="Loss of Pay Days"
          data-error-key="employee.lossOfPayDays"
          placeholder="Loss of Pay Days"
          value={String(employee.lossOfPayDays || "")}
          onChange={(v) => setEmployee((e) => ({ ...e, lossOfPayDays: v }))}
          error={submitted ? get(errors, "employee.lossOfPayDays") || "" : ""}
        />
        <Input
          variant="row"
          labelWidth={LABEL_W}
          label="Pay Date"
          data-error-key="employee.payDate"
          type="date"
          value={employee.payDate || ""}
          onChange={(v) => setEmployee((e) => ({ ...e, payDate: v }))}
          error={submitted ? get(errors, "employee.payDate") || "" : ""}
        />
      </div>

      {/* Dynamic fields (2 columns). Compact + aligned with fixed rows */}
    {/* Dynamic fields (always two columns per row on md+) */}
{/* <div className="mt-6 space-y-4">
  {(() => {
    const rows = [];
    const list = employee.extraFields || [];
    for (let i = 0; i < list.length; i += 2) {
      const left = list[i];
      const right = list[i + 1];

      rows.push(
        <div key={`row-${left?.id || i}`} className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
          // Left cell (half width) 
          {left ? (
            <FieldCell
              key={left.id}
              labelWidth={"clamp(90px, 16vw, 130px)"}   // keep aligned with fixed rows
              item={left}
              onChangeLabel={(v) => updateField(left.id, { label: v })}
              onChangeValue={(v) => updateField(left.id, { value: v })}
              onDelete={() => deleteField(left.id)}
            />
          ) : (
            <div />
          )}

          // Right cell (half width); when missing, render empty to keep 2-col layout 
          {right ? (
            <FieldCell
              key={right.id}
              labelWidth={"clamp(90px, 16vw, 130px)"}
              item={right}
              onChangeLabel={(v) => updateField(right.id, { label: v })}
              onChangeValue={(v) => updateField(right.id, { value: v })}
              onDelete={() => deleteField(right.id)}
            />
          ) : (
            <div className="hidden md:block" />   
          )}
        </div>
      );
    }
    return rows;
  })()}

  // Add button 
  <div className="flex justify-end">
    <button
      type="button"
      onClick={addField}
      className="inline-flex items-center gap-2 text-[#0f2a44] font-medium hover:opacity-90"
    >
      <span className="inline-flex h-5 w-5 items-center justify-center rounded-full border border-[#0f2a44]">+</span>
      Add field
    </button>
  </div>
</div> */}

    </section>
  );
}

/* -------- Compact, responsive dynamic cell -------- */
const FieldCell = ({
  item,
  onChangeLabel,
  onChangeValue,
  onDelete,
  errorLabel = "",
  errorValue = "",
  labelWidth = "clamp(90px, 16vw, 130px)",
  className = "",
}) => (
  <div
    className={`grid items-center gap-2 ${className}`}
    style={{ gridTemplateColumns: `${labelWidth} 8px minmax(0,1fr) auto` }}
  >
    {/* Label input */}
    <div className="min-w-0">
      <input
        className={`w-full h-9 px-2 rounded-[10px] text-[14px]
          bg-white/65 backdrop-blur-[6px]
          border ${errorLabel ? "border-red-500 ring-2 ring-red-500/50" : "border-[#10324F]/25"}
          text-[#0f2a44] placeholder:text-[#0f2a44]/40
          shadow-[inset_0_1px_0_rgba(255,255,255,0.7)]
          focus:outline-none focus:ring-2 ${errorLabel ? "focus:ring-red-500/50" : "focus:ring-[#10324F]/25"}`}
        placeholder="Name"
        value={item?.label || ""}
        onChange={(e) => onChangeLabel?.(e.target.value, e)}
        aria-invalid={!!errorLabel}
      />
      {errorLabel ? (
        <p className="mt-1 text-xs text-red-600">{errorLabel}</p>
      ) : null}
    </div>

    {/* colon */}
    <div className="text-[#0f2a44]/40 text-center">:</div>

    {/* Value input */}
    <div className="min-w-0">
      <input
        className={`w-full h-9 px-2 rounded-[10px] text-[14px]
          bg-white/65 backdrop-blur-[6px]
          border ${errorValue ? "border-red-500 ring-2 ring-red-500/50" : "border-[#10324F]/25"}
          text-[#0f2a44] placeholder:text-[#0f2a44]/40
          shadow-[inset_0_1px_0_rgba(255,255,255,0.7)]
          focus:outline-none focus:ring-2 ${errorValue ? "focus:ring-red-500/50" : "focus:ring-[#10324F]/25"}`}
        placeholder="Value"
        value={item?.value || ""}
        onChange={(e) => onChangeValue?.(e.target.value, e)}
        aria-invalid={!!errorValue}
      />
      {errorValue ? (
        <p className="mt-1 text-xs text-red-600">{errorValue}</p>
      ) : null}
    </div>

    {/* Delete (smaller) */}
    <button
      type="button"
      onClick={onDelete}
      className="ml-1 inline-flex h-7 w-7 items-center justify-center rounded-full
        border border-red-300 text-red-500 hover:bg-red-50 text-sm"
      title="Remove"
      aria-label="Remove"
    >
      –
    </button>
  </div>
);
