import React from "react";
import {
  FaTwitter,
  FaLinkedinIn,
  FaFacebookF,
  FaEnvelope,
  FaPhone,
  FaMapMarkerAlt,
} from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="relative text-white py-10 px-6 md:px-16 overflow-hidden">
      {/* ✅ Blue Background with pattern image on right */}
      <div className="absolute inset-0 -z-10 bg-[#143E72]">
        <img
          src="/footer-pattern.png" // <-- Replace with your right-side curved background image
          alt="Footer Background Pattern"
          className="absolute right-0 top-0 h-full w-auto opacity-40 object-cover"
        />
      </div>

      {/* ✅ Footer content box with border and rounded corners */}
      <div className="relative z-10 border border-[#2C5A91] rounded-xl p-8 md:p-12 bg-[#143E72]/70 backdrop-blur-sm">
        {/* Top Section */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between text-center md:text-left border-b border-gray-400/30 pb-6">
          {/* Logo + Text */}
          <div className="flex flex-col items-center md:items-start space-y-3">
            <img
              src="/epaysliplogo.png" // ✅ Ensure correct file name
              alt="ePay Slip Logo"
              className="w-[117px] h-[64px] object-contain relative z-[20]"
            />
            <p className="text-gray-200 text-sm max-w-md">
              Designed for companies and professionals to streamline salary
              processing and access records anytime, anywhere.
            </p>
          </div>

          {/* Social Icons */}
          <div className="flex justify-center md:justify-end space-x-4 mt-6 md:mt-0">
            <a href="#" className="hover:text-blue-400 transition">
              <FaTwitter size={20} />
            </a>
            <a href="#" className="hover:text-blue-400 transition">
              <FaLinkedinIn size={20} />
            </a>
            <a href="#" className="hover:text-blue-400 transition">
              <FaFacebookF size={20} />
            </a>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8 text-left">
          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-3">Quick Links</h3>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><a href="#" className="hover:underline">About Us</a></li>
              <li><a href="#" className="hover:underline">Blog</a></li>
              <li><a href="#" className="hover:underline">Pricing</a></li>
              <li><a href="#" className="hover:underline">Features</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold mb-3">Support</h3>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><a href="#" className="hover:underline">Privacy Policy</a></li>
              <li><a href="#" className="hover:underline">Cookies Policy</a></li>
              <li><a href="#" className="hover:underline">Terms & Conditions</a></li>
              <li><a href="#" className="hover:underline">Contact Us</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-3 text-sm text-gray-300">
            <div className="flex items-center space-x-3">
              <FaEnvelope className="text-blue-400" />
              <span>Email: Epayslip@gmail.com</span>
            </div>
            <div className="flex items-center space-x-3">
              <FaPhone className="text-blue-400" />
              <span>Phone Number: 656494890</span>
            </div>
            <div className="flex items-center space-x-3">
              <FaMapMarkerAlt className="text-blue-400" />
              <span>Office Address: Ajit Singh Nagar</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
